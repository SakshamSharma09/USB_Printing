package com.example.brotherusbprint

import android.graphics.Bitmap
import java.io.ByteArrayOutputStream

/**
 * Encodes a list of page bitmaps into a PCL5 print job.
 *
 * PCL5 is HP's public, documented printer control language. Brother's PCL6
 * engine (like almost all "PCL6" laser engines) auto-detects and accepts
 * classic PCL5 escape sequences for jobs like this, which keeps the encoder
 * simple: plain-text escape codes + 1-bit-per-pixel raster rows.
 *
 * Reference: HP PCL 5 Printer Language Technical Reference Manual (public).
 */
object PclEncoder {

    const val DUPLEX_OFF = 0        // simplex
    const val DUPLEX_LONG_EDGE = 1  // "book" style duplex
    const val DUPLEX_SHORT_EDGE = 2 // "tablet/flip" style duplex

    private const val ESC = '\u001B'

    /**
     * @param pages       one Bitmap per page, already rendered at [dpi], ARGB or grayscale.
     *                    Pixels are thresholded to black/white (1bpp) for the laser engine.
     * @param dpi         raster resolution to declare to the printer (300 is a safe default
     *                    for a mono laser like the DCP-B7640DWB).
     * @param copies      number of copies of the whole document (1-99).
     * @param duplexMode  one of DUPLEX_OFF / DUPLEX_LONG_EDGE / DUPLEX_SHORT_EDGE
     */
    fun buildJob(
        pages: List<Bitmap>,
        dpi: Int = 300,
        copies: Int = 1,
        duplexMode: Int = DUPLEX_OFF
    ): ByteArray {
        val out = ByteArrayOutputStream()

        fun write(s: String) = out.write(s.toByteArray(Charsets.ISO_8859_1))

        // --- Job header ---
        write("${ESC}E")                                  // Printer reset
        write("${ESC}&l${copies.coerceIn(1, 99)}X")        // Number of copies
        write("${ESC}&l${duplexMode}S")                    // Duplex mode (0/1/2)
        write("${ESC}&l0O")                                // Orientation: portrait
        write("${ESC}&l26A")                               // Page size: A4 (use "2A" for Letter)

        // --- Each page ---
        pages.forEachIndexed { index, bitmap ->
            write("${ESC}*t${dpi}R")                       // Raster resolution
            write("${ESC}*r0F")                             // Raster presentation: default
            write("${ESC}*r${bitmap.width}S")               // Raster width in pixels
            write("${ESC}*b0M")                             // Compression: 0 = none (raw)
            write("${ESC}*r1A")                              // Start raster graphics

            val rowBytes = (bitmap.width + 7) / 8
            val row = ByteArray(rowBytes)

            for (y in 0 until bitmap.height) {
                row.fill(0)
                for (x in 0 until bitmap.width) {
                    val pixel = bitmap.getPixel(x, y)
                    val r = (pixel shr 16) and 0xFF
                    val g = (pixel shr 8) and 0xFF
                    val b = pixel and 0xFF
                    val luminance = (r * 0.299 + g * 0.587 + b * 0.114)
                    val isBlack = luminance < 128
                    if (isBlack) {
                        row[x / 8] = (row[x / 8].toInt() or (0x80 shr (x % 8))).toByte()
                    }
                }
                write("${ESC}*b${rowBytes}W")
                out.write(row)
            }

            write("${ESC}*rB")                               // End raster graphics

            val isLastPage = index == pages.lastIndex
            if (!isLastPage) {
                out.write(0x0C)                              // Form feed -> next page
            }
        }

        // --- Job footer ---
        out.write(0x0C)                                       // Final form feed
        write("${ESC}E")                                      // Reset

        return out.toByteArray()
    }
}
