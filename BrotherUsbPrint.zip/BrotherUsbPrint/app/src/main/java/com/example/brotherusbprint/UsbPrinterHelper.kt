package com.example.brotherusbprint

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build

/**
 * Finds a USB printer-class device, requests permission, and sends raw bytes
 * to its bulk OUT endpoint. No vendor SDK involved.
 */
class UsbPrinterHelper(private val context: Context) {

    companion object {
        private const val ACTION_USB_PERMISSION = "com.example.brotherusbprint.USB_PERMISSION"
        private const val USB_CLASS_PRINTER = 7
    }

    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager

    /** Returns the first attached USB device that identifies as printer class, or null. */
    fun findPrinterDevice(): UsbDevice? {
        return usbManager.deviceList.values.firstOrNull { device ->
            (0 until device.interfaceCount).any { i ->
                device.getInterface(i).interfaceClass == USB_CLASS_PRINTER
            }
        }
    }

    /**
     * Requests permission for [device] if not already granted, then calls [onGranted]
     * once the user approves (or immediately if already permitted).
     */
    fun requestPermission(device: UsbDevice, onGranted: () -> Unit, onDenied: () -> Unit) {
        if (usbManager.hasPermission(device)) {
            onGranted()
            return
        }

        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            PendingIntent.FLAG_MUTABLE else 0
        val permissionIntent = PendingIntent.getBroadcast(
            context, 0, Intent(ACTION_USB_PERMISSION), flags
        )

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                if (intent.action == ACTION_USB_PERMISSION) {
                    context.unregisterReceiver(this)
                    val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    if (granted) onGranted() else onDenied()
                }
            }
        }

        val filter = IntentFilter(ACTION_USB_PERMISSION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(receiver, filter)
        }

        usbManager.requestPermission(device, permissionIntent)
    }

    /**
     * Opens the device, claims its printer interface, and writes [data] to the
     * bulk OUT endpoint in chunks. Returns true on success.
     */
    fun sendToPrinter(device: UsbDevice, data: ByteArray): Boolean {
        val printerInterface: UsbInterface = (0 until device.interfaceCount)
            .map { device.getInterface(it) }
            .firstOrNull { it.interfaceClass == USB_CLASS_PRINTER }
            ?: return false

        val outEndpoint: UsbEndpoint = (0 until printerInterface.endpointCount)
            .map { printerInterface.getEndpoint(it) }
            .firstOrNull {
                it.direction == UsbConstants.USB_DIR_OUT &&
                    it.type == UsbConstants.USB_ENDPOINT_XFER_BULK
            } ?: return false

        val connection: UsbDeviceConnection = usbManager.openDevice(device) ?: return false

        return try {
            if (!connection.claimInterface(printerInterface, true)) return false

            val chunkSize = 16 * 1024
            var offset = 0
            while (offset < data.size) {
                val len = minOf(chunkSize, data.size - offset)
                val sent = connection.bulkTransfer(
                    outEndpoint, data, offset, len, 10_000
                )
                if (sent < 0) return false
                offset += sent
            }
            true
        } finally {
            connection.releaseInterface(printerInterface)
            connection.close()
        }
    }
}
