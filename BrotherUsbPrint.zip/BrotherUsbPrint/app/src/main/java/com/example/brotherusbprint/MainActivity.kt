package com.example.brotherusbprint

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.hardware.usb.UsbDevice
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.brotherusbprint.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var usbHelper: UsbPrinterHelper

    private var connectedDevice: UsbDevice? = null
    private var pickedFileUri: Uri? = null

    private val duplexOptions = listOf(
        "Off (single-sided)" to PclEncoder.DUPLEX_OFF,
        "On - flip on long edge (book)" to PclEncoder.DUPLEX_LONG_EDGE,
        "On - flip on short edge (tablet)" to PclEncoder.DUPLEX_SHORT_EDGE
    )

    private val pickFileLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            pickedFileUri = uri
            binding.fileText.text = uri.lastPathSegment ?: uri.toString()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        usbHelper = UsbPrinterHelper(this)

        binding.duplexSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, duplexOptions.map { it.first }
        )

        binding.btnConnect.setOnClickListener { connectToPrinter() }
        binding.btnPickFile.setOnClickListener {
            pickFileLauncher.launch(arrayOf("application/pdf"))
        }
        binding.btnPrint.setOnClickListener { startPrintJob() }

        // If the app was launched because the printer was just plugged in.
        if (intent?.action == "android.hardware.usb.action.USB_DEVICE_ATTACHED") {
            connectToPrinter()
        }
    }

    private fun connectToPrinter() {
        val device = usbHelper.findPrinterDevice()
        if (device == null) {
            binding.statusText.text = "No printer detected. Plug in the OTG cable and try again."
            return
        }
        usbHelper.requestPermission(
            device,
            onGranted = {
                connectedDevice = device
                binding.statusText.text = "Connected: ${device.productName ?: device.deviceName}"
            },
            onDenied = {
                binding.statusText.text = "USB permission denied."
            }
        )
    }

    private fun startPrintJob() {
        val device = connectedDevice
        val uri = pickedFileUri
        if (device == null) {
            toast("Connect to the printer first")
            return
        }
        if (uri == null) {
            toast("Choose a PDF first")
            return
        }

        val copies = binding.copiesInput.text.toString().toIntOrNull()?.coerceIn(1, 99) ?: 1
        val duplexMode = duplexOptions[binding.duplexSpinner.selectedItemPosition].second

        binding.progressBar.visibility = android.view.View.VISIBLE
        binding.btnPrint.isEnabled = false

        lifecycleScope.launch {
            try {
                val pages = withContext(Dispatchers.IO) { renderPdfToBitmaps(uri) }
                val jobBytes = withContext(Dispatchers.Default) {
                    PclEncoder.buildJob(pages, dpi = 300, copies = copies, duplexMode = duplexMode)
                }
                val success = withContext(Dispatchers.IO) {
                    usbHelper.sendToPrinter(device, jobBytes)
                }
                toast(if (success) "Sent to printer" else "Failed to send print job")
            } catch (e: Exception) {
                toast("Error: ${e.message}")
            } finally {
                binding.progressBar.visibility = android.view.View.INVISIBLE
                binding.btnPrint.isEnabled = true
            }
        }
    }

    /** Renders every page of the PDF at [uri] to a 1-bit-ready ARGB bitmap at ~300dpi. */
    private fun renderPdfToBitmaps(uri: Uri, dpi: Int = 300): List<Bitmap> {
        val pfd: ParcelFileDescriptor = contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalStateException("Could not open PDF")

        val bitmaps = mutableListOf<Bitmap>()
        PdfRenderer(pfd).use { renderer ->
            for (i in 0 until renderer.pageCount) {
                renderer.openPage(i).use { page ->
                    // PDF page size is in points (1/72"); scale to target dpi.
                    val scale = dpi / 72f
                    val width = (page.width * scale).toInt()
                    val height = (page.height * scale).toInt()

                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                    bitmaps.add(bitmap)
                }
            }
        }
        return bitmaps
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }
}
